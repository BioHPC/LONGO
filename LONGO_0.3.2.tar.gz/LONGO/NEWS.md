## LONGO 0.3.2

### Main changes
    - Updated GO analysis to use just Longe Gene Expression (LGE)
________________________________________________________________________________

## LONGO 0.3.1

### Main changes
    - Added documentation for GitHub Pages
________________________________________________________________________________

## LONGO 0.3.0

### Main changes
    - Added GO analysis graphing with multi parameter input
________________________________________________________________________________

## LONGO 0.2.3

### Main changes
    - Altered plot labels for LONGO output
    - Mopdified exampleData for example data analysis
________________________________________________________________________________

## LONGO 0.2.2

### Main changes
    - Updated README and vignette files
________________________________________________________________________________

## LONGO 0.2.1

### Main changes
    - Fixed bug in calculating long gene quotient
    - modified analysis by removing genes which have a length less than the median before completing the analysis step
    - modified few variable names
________________________________________________________________________________

## LONGO 0.2.0

### Main changes
    - Modified README and some vignette files
________________________________________________________________________________
